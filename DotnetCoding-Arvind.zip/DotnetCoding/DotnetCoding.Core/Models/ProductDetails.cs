﻿

using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace DotnetCoding.Core.Models
{
    public class ProductDetails
    {
        public int Id { get; set; }

        [Required]
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        
        [Required]
        public int ProductPrice { get; set; }

        [JsonIgnore]
        public string ProductStatus { get; set; }
        
        [JsonIgnore]
        public DateTime ProductCreatedDate { get; set; }

    }
}
