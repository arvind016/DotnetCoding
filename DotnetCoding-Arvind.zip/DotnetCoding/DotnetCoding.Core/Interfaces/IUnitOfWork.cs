﻿

using DotnetCoding.Core.Models;

namespace DotnetCoding.Core.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        IProductRepository Products { get; }

        int Save();

        public List<ProductDetails> GetProductList();
        public List<ProductQueueDetails> GetProductsInApprovalQueue();
        public List<ProductDetails> SearchProductAsync(ProductSearch productSearch);
        public ProductDetails GetProductByIdAsync(int id);
        public bool SaveProductAsync(ProductDetails product);
        public bool UpdateProductAsync(ProductDetails product);
        public bool DeleteProductAsync(int id);
        public bool FindProductAsync(int id);
        public bool ProductStatusChangeAsync(int ProductId, bool IsApproved);
    }
}

