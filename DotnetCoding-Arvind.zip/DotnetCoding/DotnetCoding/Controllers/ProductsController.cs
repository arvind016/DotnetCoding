﻿using Microsoft.AspNetCore.Mvc;
using DotnetCoding.Core.Models;
using DotnetCoding.Services.Interfaces;

namespace DotnetCoding.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        public readonly IProductService _productService;
        public ProductsController(IProductService productService)
        {
            _productService = productService;
        }

        /// <summary>
        /// Get the list of product
        /// </summary>
        /// <returns></returns>
        //[HttpGet]
        //public async Task<IActionResult> GetProductList()
        //{
        //    var productDetailsList = await _productService.GetAllProducts();

        //    if (productDetailsList == null)
        //    {
        //        return NotFound();
        //    }
        //    return Ok(productDetailsList);
        //}

        /// <summary>
        /// Search Products by Name, Price Range and Posted Date Range.
        /// </summary>
        /// <returns></returns>
       
        [HttpGet("SearchProducts")]
        public async Task<IActionResult> SearchProducts(string productName, int minPrice, int maxPrice, DateTime minPostedDate, DateTime maxPostedDate)
        {
            ProductSearch searchParam = new ProductSearch();
            searchParam.Name= productName;
            searchParam.MinPrice= minPrice;
            searchParam.MaxPrice= maxPrice;
            searchParam.MinPostedDate= minPostedDate;   
            searchParam.MaxPostedDate= maxPostedDate;

            var productDetailsList = await _productService.SearchProducts(searchParam);
            if (productDetailsList == null)
            {
                return NotFound("No active product found.");
            }
            return Ok(productDetailsList);
        }

        /// <summary>
        /// Get list of Products in Approval Queue.
        /// </summary>
        /// <returns></returns>
        [HttpGet("ProductsInApprovalQueue")]
        public async Task<IActionResult> ProductInQueueList()
        {

            var productDetailsList = await _productService.GetProductInQueueList();
            if (productDetailsList == null)
            {
                return NotFound("No product found in awaiting queue.");
            }
            return Ok(productDetailsList);
        }

        /// <summary>
        /// Create New Product
        /// </summary>
        /// <returns></returns>
        [HttpPost("CreateNewProduct")]
        public async Task<IActionResult> Post([FromForm] ProductDetails product)
        {
            if (product == null || product.ProductName == "")
            {
                if (product == null)
                    return BadRequest("Product data is invalid.");
                else if (product.ProductName.Length<=0)
                    return BadRequest($"Product Name is Required.");
            }

            if (product.ProductPrice > 10000)
            {
                return BadRequest("Product price should be less than 10000.");
            }

            try
            {
                var isSuccess = await _productService.CreateProduct(product);
                if (isSuccess)
                    return Ok("Product Created Successfuly.");
                else
                    return BadRequest("Error while creating product.");
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Update Product
        /// </summary>
        /// <returns></returns>
        [HttpPut("UpdateProduct")]
        public async Task<IActionResult> Put([FromForm] ProductDetails product)
        {
            if (product == null || product.Id == 0)
            {
                if (product == null)
                    return BadRequest("Product data is invalid.");
                else if (product.Id == 0)
                    return BadRequest($"Product id {product.Id} is invalid.");
            
            }
            if (product.ProductPrice > 10000)
            {
                return BadRequest("Product price should be less than 10000.");
            }

            try
            {
                var isSuccess = await _productService.UpdateProduct(product);
                if (isSuccess)
                    return Ok("Product Updated Successfuly.");
                else
                    return BadRequest("Error while updating product.");
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Delete Product
        /// </summary>
        /// <returns></returns>
        [HttpDelete("DeleteProduct")]
        public async Task<IActionResult> Delete(int id)
        {
            if(id==0)
                return BadRequest($"Product id {id} is invalid.");

            try
            {
                var isSuccess = await _productService.DeleteProduct(id);
                if (isSuccess)
                    return Ok("Product Deleted Successfuly.");
                else
                    return BadRequest("Error while deleting product.");
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Approve or Reject Product.
        /// </summary>
        /// <returns></returns>
        [HttpPut("ProductStatusChange")]
        public async Task<IActionResult> ProductStatusChange(int ProductId, bool IsApproved)
        {
            if (ProductId == 0)
            {
                return BadRequest($"Product id {ProductId} is invalid.");
            }
            try
            {
                var isSuccess = await _productService.ProductStatusChange(ProductId, IsApproved);
                if (isSuccess)
                    return Ok("Product Status Updated Successfuly.");
                else
                    return BadRequest("Error while updating product status.");
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }
    }
}
