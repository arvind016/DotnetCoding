﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DotnetCoding.Core.Interfaces;
using DotnetCoding.Core.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace DotnetCoding.Infrastructure.Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly DbContextClass _dbContext;
        public IProductRepository Products { get; }

        public UnitOfWork(DbContextClass dbContext,
                            IProductRepository productRepository)
        {
            _dbContext = dbContext;
            Products = productRepository;
        }

        public int Save()
        {
            return _dbContext.SaveChanges();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
        }

        /* Get All Active Products */
        List<ProductDetails> IUnitOfWork.GetProductList()
        {
            List<ProductDetails> lst = new List<ProductDetails>();
            using (var context = _dbContext)
            {
                try
                {
                    using (SqlConnection con = new SqlConnection(context.Database.GetDbConnection().ConnectionString))
                    {
                        string sql = "SELECT [Id],[ProductName],[ProductDescription],[ProductPrice],[ProductStatus],[ProductCreatedDate],[ProductUpatedDate]  FROM [Products] Where [ProductStatus]='Active' Order by [ProductCreatedDate] DESC";
                        SqlCommand cmd = new SqlCommand(sql, con);
                        cmd.CommandType = CommandType.Text;
                        con.Open();
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            ProductDetails products = new ProductDetails();
                            products.Id = Convert.ToInt32(reader["Id"]);
                            products.ProductPrice = Convert.ToInt32(reader["ProductPrice"]);
                            products.ProductCreatedDate = Convert.ToDateTime(reader["ProductCreatedDate"].ToString());
                            products.ProductName = reader["ProductName"].ToString();
                            products.ProductDescription = reader["ProductDescription"].ToString();
                            products.ProductStatus = reader["ProductStatus"].ToString();
                            lst.Add(products);
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }

            }
            return lst;
        }

        /* Get All Products In Queue */
        List<ProductQueueDetails> IUnitOfWork.GetProductsInApprovalQueue()
        {
            List<ProductQueueDetails> lst = new List<ProductQueueDetails>();
            using (var context = _dbContext)
            {
                try
                {
                    using (SqlConnection con = new SqlConnection(context.Database.GetDbConnection().ConnectionString))
                    {
                        string sql = " Select  q.[ProductId], q.Id, p.[ProductName],q.[RequestReason],q.[RequestDate],p.[ProductStatus],q.[RequestStatus] From [Products]  p INNER JOIN [ApprovalQueue] q ON q.ProductId = p.Id ";
                        sql += " Where p.ProductStatus ='Pending Approval' AND q.RequestIsPosted = 0 AND q.RequestIsApproved =0 ";
                        sql += " Order by q.RequestDate ";

                        SqlCommand cmd = new SqlCommand(sql, con);
                        cmd.CommandType = CommandType.Text;
                        con.Open();
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            ProductQueueDetails products = new ProductQueueDetails();
                            products.Id = Convert.ToInt32(reader["Id"]);
                            products.ProductId = Convert.ToInt32(reader["ProductId"]);
                            products.RequestDate = Convert.ToDateTime(reader["RequestDate"].ToString());
                            products.ProductName = reader["ProductName"].ToString();
                            products.RequestReason = reader["RequestReason"].ToString();
                            products.ProductStatus = reader["ProductStatus"].ToString();
                            products.RequestStatus = reader["RequestStatus"].ToString();
                            lst.Add(products);
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }

            }
            return lst;
        }

        /* Search Products */
        List<ProductDetails> IUnitOfWork.SearchProductAsync(ProductSearch productSearch)
        {
            List<ProductDetails> lst = new List<ProductDetails>();
            using (var context = _dbContext)
            {
                try
                {
                    using (SqlConnection con = new SqlConnection(context.Database.GetDbConnection().ConnectionString))
                    {
                        SqlCommand cmd = new SqlCommand("usp_SearchProduct", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@pName", productSearch.Name);
                        cmd.Parameters.AddWithValue("@pMinPrice", productSearch.MinPrice);
                        cmd.Parameters.AddWithValue("@pMaxPrice", productSearch.MaxPrice);
                        cmd.Parameters.AddWithValue("@pMinPostedDate", productSearch.MinPostedDate);
                        cmd.Parameters.AddWithValue("@pMaxPostedDate", productSearch.MaxPostedDate);
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            ProductDetails products = new ProductDetails();
                            products.Id = Convert.ToInt32(reader["ProductId"]);
                            products.ProductPrice = Convert.ToInt32(reader["ProductPrice"]);
                            products.ProductCreatedDate = Convert.ToDateTime(reader["ProductCreatedDate"].ToString());
                            products.ProductName = reader["ProductName"].ToString();
                            products.ProductDescription = reader["ProductDescription"].ToString();
                            products.ProductStatus = reader["ProductStatus"].ToString();
                            lst.Add(products);
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }

            }
            return lst;
        }

        

        

        /* Create New Project */
        public bool SaveProductAsync(ProductDetails product)
        {
            var issuccess = true;

            using (var context = _dbContext)
            {
                try
                {
                    if (product.ProductPrice < 10000)
                    {
                        bool RequestIsPosted = true;
                        bool RequestIsApproved = true;
                        string RequestType = "Add New Product";
                        string RequestReason = "Product price is less than 5000.";
                        product.ProductStatus = "Active";

                        if (product.ProductPrice > 5000)
                        {
                            product.ProductStatus = "Pending Approval";
                            RequestReason = "Product price is greater than 5000.";
                            RequestIsPosted = false;
                            RequestIsApproved = false;

                        }

                        using (SqlConnection con = new SqlConnection(context.Database.GetDbConnection().ConnectionString))
                        {
                            SqlCommand cmd = new SqlCommand("usp_SaveProduct", con);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@pName", product.ProductName);
                            cmd.Parameters.AddWithValue("@pDesc", product.ProductDescription);
                            cmd.Parameters.AddWithValue("@pPrice", product.ProductPrice);
                            cmd.Parameters.AddWithValue("@pStatus", product.ProductStatus);
                            cmd.Parameters.AddWithValue("@pRequestType", RequestType);
                            cmd.Parameters.AddWithValue("@pRequestReason", RequestReason);
                            cmd.Parameters.AddWithValue("@pRequestIsPosted", RequestIsPosted);
                            cmd.Parameters.AddWithValue("@pRequestIsApproved", RequestIsApproved);
                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }

                    }
                    else
                    {
                        issuccess = false;
                        throw new ApplicationException("Product creation is not allowed.");
                    }


                }
                catch (Exception ex)
                {
                    issuccess = false;
                    throw new Exception(ex.Message);
                }

            }

            return issuccess;
        }

        /* Update Product */
        public bool UpdateProductAsync(ProductDetails product)
        {
            var issuccess = true;
            ProductDetails currProduct = GetProductByIdAsync(product.Id);

            using (var context = _dbContext)
            {
                try
                {
                    if (product.ProductPrice < 10000)
                    {
                        bool RequestIsPosted = true;
                        bool RequestIsApproved = true;
                        string RequestType = "Update Product";
                        string RequestReason = "Product price is less than 5000.";
                        product.ProductStatus = "Active";
                        if (product.ProductPrice > 5000 || (product.ProductPrice > (currProduct.ProductPrice) / 2))
                        {
                            product.ProductStatus = "Pending Approval";
                            RequestReason = "Product price is greater than 5000 or more than 50% of its previous price.";
                            RequestIsPosted = false;
                            RequestIsApproved = false;

                        }
                        using (SqlConnection con = new SqlConnection(context.Database.GetDbConnection().ConnectionString))
                        {
                            SqlCommand cmd = new SqlCommand("usp_UpdateProduct", con);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@pId", product.Id);
                            cmd.Parameters.AddWithValue("@pName", product.ProductName);
                            cmd.Parameters.AddWithValue("@pDesc", product.ProductDescription != null ? product.ProductDescription : currProduct.ProductDescription);
                            cmd.Parameters.AddWithValue("@pPrice", product.ProductPrice > 0 ? product.ProductPrice : currProduct.ProductPrice);
                            cmd.Parameters.AddWithValue("@pStatus", product.ProductStatus != null ? product.ProductStatus : currProduct.ProductStatus);
                            cmd.Parameters.AddWithValue("@pRequestType", RequestType);
                            cmd.Parameters.AddWithValue("@pRequestReason", RequestReason);
                            cmd.Parameters.AddWithValue("@pRequestIsPosted", RequestIsPosted);
                            cmd.Parameters.AddWithValue("@pRequestIsApproved", RequestIsApproved);
                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }

                    }
                    else
                    {
                        issuccess = false;
                        throw new ApplicationException("Product update is not allowed.");
                    }


                }
                catch (Exception ex)
                {
                    issuccess = false;
                    throw new Exception(ex.Message);
                }

            }

            return issuccess;
        }

        /* Delete Product*/
        public bool DeleteProductAsync(int id)
        {
            var issuccess = true;

            using (var context = _dbContext)
            {
                try
                {
                    using (SqlConnection con = new SqlConnection(context.Database.GetDbConnection().ConnectionString))
                    {
                        SqlCommand cmd = new SqlCommand("usp_DeleteProduct", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@pId", id);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }

                }
                catch (Exception ex)
                {
                    issuccess = false;
                    throw new Exception(ex.Message);
                }

            }


            return issuccess;
        }

        /* Approve/Reject Product */
        public bool ProductStatusChangeAsync(int ProductId,bool IsApproved)
        {
            var issuccess = true;
            using (var context = _dbContext)
            {
                try
                {
                    using (SqlConnection con = new SqlConnection(context.Database.GetDbConnection().ConnectionString))
                    {
                        SqlCommand cmd = new SqlCommand("usp_UpdateProductStatus", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@pId", ProductId);                        
                        cmd.Parameters.AddWithValue("@pIsApproved", IsApproved);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }

                }
                catch (Exception ex)
                {
                    issuccess = false;
                    throw new Exception(ex.Message);
                }

            }

            return issuccess;
        }
        
        /* Find Product By Id */
        public ProductDetails GetProductByIdAsync(int id)
        {
            try
            {
                ProductDetails product = new ProductDetails();
                var context = _dbContext;
                SqlConnection con = new SqlConnection(context.Database.GetDbConnection().ConnectionString);
                string sqlGetProductById = "SELECT [Id],[ProductName],[ProductDescription],[ProductPrice],[ProductStatus],[ProductCreatedDate],[ProductUpatedDate]  FROM [Products] WHERE [Id]=" + id;
                SqlCommand cmd = new SqlCommand(sqlGetProductById, con);
                cmd.CommandType = CommandType.Text;
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    product.Id = Convert.ToInt32(reader["Id"]);
                    product.ProductPrice = Convert.ToInt32(reader["ProductPrice"]);
                    product.ProductCreatedDate = Convert.ToDateTime(reader["ProductCreatedDate"].ToString());
                    product.ProductName = reader["ProductName"].ToString();
                    product.ProductDescription = reader["ProductDescription"].ToString();
                    product.ProductStatus = reader["ProductStatus"].ToString();
                }
                con.Close();
                return product;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }


        /* Find Product */
        public bool FindProductAsync(int id)
        {
            try
            {
                var issuccess = false;
                var context = _dbContext;
                SqlConnection con = new SqlConnection(context.Database.GetDbConnection().ConnectionString);
                string sqlGetProductById = "SELECT COUNT(Id) IdCount FROM [Products] Where Id=" + id;
                SqlCommand cmd = new SqlCommand(sqlGetProductById, con);
                cmd.CommandType = CommandType.Text;
                con.Open();
                var result = cmd.ExecuteScalar();
                if (Convert.ToInt32(result) > 0)
                    issuccess = true;

                con.Close();

                return issuccess;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

    }
}
