﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DotnetCoding.Core.Models;

namespace DotnetCoding.Services.Interfaces
{
    public interface IProductService
    {
        Task<IEnumerable<ProductDetails>> GetAllProducts();

        Task<List<ProductDetails>> GetProductList();
        Task<List<ProductQueueDetails>> GetProductInQueueList();
        Task<List<ProductDetails>> SearchProducts(ProductSearch productSearch);

        Task<bool> CreateProduct(ProductDetails product);
        Task<bool> UpdateProduct(ProductDetails product);
        Task<bool> DeleteProduct(int id);
        Task<bool> FindProduct(int id);
        Task<bool> ProductStatusChange(int ProductId, bool IsApproved);

    }
}
