﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DotnetCoding.Core.Interfaces;
using DotnetCoding.Core.Models;
using DotnetCoding.Services.Interfaces;

namespace DotnetCoding.Services
{
    public class ProductService : IProductService
    {
        public IUnitOfWork _unitOfWork;

        public ProductService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<IEnumerable<ProductDetails>> GetAllProducts()
        {
            var productDetailsList = await _unitOfWork.Products.GetAll();
            return productDetailsList;
        }

        public async Task<List<ProductDetails>> GetProductList()
        {
            List<ProductDetails> productList = new List<ProductDetails>();
            productList = await Task.Run(() => _unitOfWork.GetProductList());
            return productList;
        }

        public async Task<List<ProductQueueDetails>> GetProductInQueueList()
        {
            List<ProductQueueDetails> productList = new List<ProductQueueDetails>();
            productList = await Task.Run(() => _unitOfWork.GetProductsInApprovalQueue());
            return productList;
        }

        public async Task<List<ProductDetails>> SearchProducts(ProductSearch productSearch)
        {
            List<ProductDetails> productList = new List<ProductDetails>();
            productList = await Task.Run(() => _unitOfWork.SearchProductAsync(productSearch));
            return productList;
        }
        public async Task<bool> CreateProduct(ProductDetails product)
        {
            var result = await Task.Run(() => _unitOfWork.SaveProductAsync(product));
            return result;
        }

        public async Task<bool> UpdateProduct(ProductDetails product)
        {
            var result = await Task.Run(() => _unitOfWork.UpdateProductAsync(product));
            return result;
        }

        public async Task<bool> DeleteProduct(int id)
        {
            var result = await Task.Run(() => _unitOfWork.DeleteProductAsync(id));
            return result;
        }
        public async Task<bool> FindProduct(int id)
        {
            var result = await Task.Run(() => _unitOfWork.FindProductAsync(id));
            return result;
        }
        public async Task<bool> ProductStatusChange(int ProductId, bool IsApproved)
        {
            var result = await Task.Run(() => _unitOfWork.ProductStatusChangeAsync(ProductId, IsApproved));
            return result;
        }
    }
}
